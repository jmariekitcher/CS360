package com.example.jacquelinkitchereventapp;
// The creation of this class was necessary to act as a container to hold
//individual event details.
//Class declaration
public class Event {
    //We want the user to be able to enter in the title of their event, a
    //short description, and the date of the event.
    private String title;
    private String description;
    private String date;

    //Class constructor
    public Event(String title, String description, String date) {
        this.title = title;
        this.description = description;
        this.date = date;
    }

    // Getters
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getDate() { return date; }
}


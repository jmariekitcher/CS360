
package com.example.jacquelinkitchereventapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.content.DialogInterface;
import android.app.DatePickerDialog;
import java.util.Calendar;

import com.example.jacquelinkitchereventapp.Event;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;


import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
//The purpose I created this HomeDashBoard class is to redirect you to this
//screen upon successful login. This dashboard should display a recycler view
//so that as more events are added, a person can scroll through them all fluidly.
//I also added a Floating Action Button(FAB) which can be used to add new events.
//This class handles that creation and accepts the title, description, and date
//for the event added.

//Class declaration
public class HomeDashBoard extends AppCompatActivity {

    //class attributes
    private RecyclerView recyclerView;
    private FloatingActionButton fabAddEvent;
    private EventAdapter adapter;
    private List<Event> eventList;

    //load dashboard
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_dash_board);
        recyclerView = findViewById(R.id.recyclerViewEvents);
        fabAddEvent = findViewById(R.id.fabAddEvent);

        eventList = new ArrayList<>();
        adapter = new EventAdapter(eventList, event -> {
            showEventDetails(event);
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        fabAddEvent.setOnClickListener(v -> showAddEventDialog());
    }
    //add event via FAB
    private void showAddEventDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Event");

        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_event, null);
        EditText titleInput = dialogView.findViewById(R.id.editTitle);
        EditText descInput = dialogView.findViewById(R.id.editDesc);
        EditText dateInput = dialogView.findViewById(R.id.eventDate);

        dateInput.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
                String date = (month + 1) + "/" + dayOfMonth + "/" + year;
                dateInput.setText(date);
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
            datePickerDialog.show();
        });
        builder.setView(dialogView);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String title = titleInput.getText().toString().trim();
            String desc = descInput.getText().toString().trim();
            String date = dateInput.getText().toString().trim();

            if (!title.isEmpty() && !dateInput.getText().toString().isEmpty()) {
                Event newEvent = new Event(title, desc, date);
                eventList.add(newEvent);
                adapter.notifyItemInserted(eventList.size() - 1);
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());

        builder.show();
    }
    private void showEventDetails(Event event) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(event.getTitle());
        builder.setMessage(event.getDescription());
        builder.setPositiveButton("OK", (dialog, which) -> dialog.dismiss());
        builder.show();
    }
}